package yugo.req;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class Parcels {

    private String parcelNo; //包裹编号
    private String parcelDesc; //包裹描述
    private BigDecimal length; //包裹长度 单位cm
    private BigDecimal width; //包裹宽度 单位cm
    private BigDecimal height; //包裹高度 单位cm
    private BigDecimal volume; //包裹体积 单位CBM
    private BigDecimal weight; //包裹重量 单位kg
    private List<ParcelItems> parcelItems; //商品信息集合
}
