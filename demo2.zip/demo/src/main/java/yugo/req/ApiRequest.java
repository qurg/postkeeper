package yugo.req;

import lombok.Data;

import java.util.Date;

@Data
public class ApiRequest  {

    /**
     * 接口动作
     */
    private String            action;
    /**
     * 平台用户名
     */
    private String            appKey;
    /**
     * 格式，默认json
     */
    private String            format;
    /**
     * 语言，默认zh_CN
     */
    private String            language;
    /**
     * 平台
     */
    private String            platform;
    /**
     *
     */
    private String            sign;
    /**
     * 加密方式,默认MD5
     */
    private String            signMethod;
    /**
     * 时间，格式yyyy-MM-dd HH:mm:ss
     */
    private Date              timestamp;
    /**
     * 版本号，默认为1.0
     */
    private String            version;
    /**
     *
     */
    private Object            data;


}
