package yugo.util;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.io.IOUtils;

/**
 * http请求工具类
 *
 * @version 2019-11-12
 */
public class HttpClientUtils {

    public static final String CONTENTTYPE = "application/json";
    public static final String CHARSET     = "UTF-8";

    protected static HttpClient getHttpClient() {
        HttpClient httpClient = new HttpClient(new MultiThreadedHttpConnectionManager());
        httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(60 * 5 * 1000);
        httpClient.getHttpConnectionManager().getParams().setSoTimeout(60 * 5 * 1000);
        return httpClient;
    }



    /**
     * Post调用接口，入参格式为Json格式字符串
     *
     * @param url 调用的URL
     * @param jsonData 传入参数
     * @return 返回的结果
     */
    public static String doPost(String url, String jsonData) {
        System.out.println("调用第三方URL:" + url + ",入参：" + jsonData);
        String result = null;
        PostMethod post = null;
        try {

            StringRequestEntity entity = new StringRequestEntity(jsonData, CONTENTTYPE, CHARSET);

            post = new PostMethod(url);
            post.setRequestEntity(entity);

            int statusCode = getHttpClient().executeMethod(post);

            if (statusCode == HttpStatus.SC_OK) {
                result = IOUtils.toString(post.getResponseBodyAsStream(), CHARSET);
            }

        } catch (Exception e) {
            System.out.println("调用接口异常：" +e);
        } finally {
            if (post != null) {
                post.releaseConnection();
            }
        }
        System.out.println("调用第三方URL:"+url+",出参："+result);
        return result;
    }


}
