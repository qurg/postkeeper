package yugo.util;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.commons.lang3.StringUtils;
import yugo.req.ApiRequest;

/**
 * 签名工具类
 *
 * @version 2019-11-12
 */
public class SignUtil {

    /**
     * 签名具体算法排序实现
     * 
     * @param apiRequest 请求对象
     * @param token 加密秘钥：用户token或者client_secret
     * 需要特别注意：系统参数language和client_id是后续加入，没有参与签名算法
     * @return
     */
    private static String buildJsonStr(ApiRequest apiRequest, String token, String format) {
        StringBuffer buf = new StringBuffer();
        buf.append(token);
        buf.append("action").append(apiRequest.getAction());
        buf.append("appKey").append(apiRequest.getAppKey());
        String data = "";
        if (apiRequest.getData() != null && StringUtils.isNotBlank(apiRequest.getData().toString())) {
            // 此处需要注意com.alibaba.fastjson.JSONObject的默认行为是不显示值为null的键，且默认字段是强制排序的。故如果使用其他JSON工具需要注意这两点，不然会认证不过
            data = JSONObject.toJSONString(apiRequest.getData(), SerializerFeature.MapSortField);
        }
        buf.append("data").append(data);
        buf.append("format").append(apiRequest.getFormat() == null ? "" : apiRequest.getFormat());
        buf.append("platform").append(apiRequest.getPlatform() == null ? "" : apiRequest.getPlatform());
        buf.append("signMethod").append(apiRequest.getSignMethod() == null ? "" : apiRequest.getSignMethod());
        buf.append("timestamp");
        if (apiRequest.getTimestamp() == null) {
            buf.append("");
        } else {
            if (format.equals("1")) {
                buf.append(apiRequest.getTimestamp());
            } else {
                String dataStr = DateUtils.formatDateTime(apiRequest.getTimestamp());
                buf.append(dataStr);
            }
        }
        buf.append("version").append(apiRequest.getVersion() == null ? "" : apiRequest.getVersion());
        buf.append(token);
        System.out.println(("组装加密串-->"+format + "---->" + buf.toString()));
        return buf.toString();
    }

    private static String buildJsonStr(ApiRequest apiRequest, String token) {
        return buildJsonStr(apiRequest, token, "1");
    }

    /**
     * 按字段名字母顺序排列 对参数进行MD5加密取得签名
     * 
     * @param apiRequest
     * @param token
     * @return
     */
    public static String getSign(ApiRequest apiRequest, String token) {
        return MD5Util.getMd5(buildJsonStr(apiRequest, token));
    }

    /**
     * 按字段名字母顺序排列 对参数进行MD5加密取得签名
     * 兼容时间yyyy
     * @param apiRequest
     * @param token
     * @return
     */
    public static String getSign2(ApiRequest apiRequest, String token) {
        return MD5Util.getMd5(buildJsonStr(apiRequest, token,"2"));
    }

    public static void main(String[] args) {
        String c = "87ae42f6b7e049baa70c8129b541d389actionapi.postorder.createappKeytestdata{\"buyerAddress1\":\"Multiplex-Andrew Olliver 22 Bishopsgate Project Office\",\"buyerAddress2\":\"\",\"buyerCity\":\"LONDON\",\"buyerCountry\":\"GB\",\"buyerEmail\":\"abc@123.com\",\"buyerHouseNo\":\"\",\"buyerName\":\"Lauren Carnahan\",\"buyerPhone\":\"7471770205\",\"buyerPostcode\":\"EC3A 8EE\",\"buyerState\":\"LONDON\",\"customerOrderNo\":\"1101986699\",\"parcels\":[{\"height\":0.5,\"length\":0.5,\"parcelDesc\":\"LV\",\"parcelItems\":[{\"declaredCurrency\":\"USD\",\"declaredNameCn\":\"包\",\"declaredNameEn\":\"LV\",\"declaredValue\":5,\"height\":10,\"itemCode\":\"BAG\",\"itemName\":\"LV\",\"length\":10,\"qty\":1,\"saleCurrency\":\"USD\",\"salePrice\":5,\"volume\":0.001,\"weight\":0.5,\"width\":10}],\"parcelNo\":\"001\",\"volume\":0.125,\"weight\":0.5,\"width\":0.5}],\"productCode\":\"P2019080100000004\",\"warehouseCode\":\"ZFX_US_KY\"}formatjsonplatformFSsignMethodmd5timestampMon Nov 11 21:11:48 CST 2019version1.087ae42f6b7e049baa70c8129b541d389";
        String d = "87ae42f6b7e049baa70c8129b541d389actionapi.postorder.createappkeytestdata{\"buyerAddress1\":\"Multiplex-Andrew Olliver 22 Bishopsgate Project Office\",\"buyerAddress2\":\"\",\"buyerCity\":\"LONDON\",\"buyerCountry\":\"GB\",\"buyerEmail\":\"abc@123.com\",\"buyerHouseNo\":\"\",\"buyerName\":\"Lauren Carnahan\",\"buyerPhone\":\"7471770205\",\"buyerPostcode\":\"EC3A 8EE\",\"buyerState\":\"LONDON\",\"customerOrderNo\":\"1101986699\",\"parcels\":[{\"height\":0.5,\"length\":0.5,\"parcelNo\":\"001\",\"parcelDesc\":\"LV\",\"width\":0.5,\"weight\":0.5,\"volume\":0.125,\"parcelItems\":[{\"declaredCurrency\":\"USD\",\"declaredNameCn\":\"包\",\"declaredNameEn\":\"LV\",\"declaredValue\":5,\"height\":10,\"itemCode\":\"BAG\",\"itemName\":\"LV\",\"length\":10,\"qty\":1,\"saleCurrency\":\"USD\",\"salePrice\":5,\"volume\":0.001,\"weight\":0.5,\"width\":10}]}],\"productCode\":\"P2019080100000004\",\"warehouseCode\":\"ZFX_US_KY\"}formatjsonplatformFSsignMethodmd5timestampMon Nov 11 21:12:15 CST 2019version1.087ae42f6b7e049baa70c8129b541d389";
        System.out.println(MD5Util.getMd5(c));
        System.out.println(MD5Util.getMd5(d));
    }
}
