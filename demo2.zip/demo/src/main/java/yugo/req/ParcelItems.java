package yugo.req;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ParcelItems {

    private String itemCode; //商品编码
    private String itemName; //商品名称
    private String saleCurrency; //销售币种
    private BigDecimal salePrice; //销售单价
    private String declaredCurrency; //报关币种
    private String declaredNameCn; //报关中文名称
    private String declaredNameEn; //报关英文名称
    private BigDecimal declaredValue; //申报价值
    private BigDecimal length; //商品长度 单位cm
    private BigDecimal width; //商品宽度 单位cm
    private BigDecimal height; //商品高度 单位cm
    private BigDecimal volume; //商品体积 单位cbm
    private BigDecimal weight; //商品重量 单位kg
    private Integer qty; //商品数量
}
