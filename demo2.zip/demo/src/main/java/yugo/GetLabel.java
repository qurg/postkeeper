package yugo;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import yugo.req.ApiRequest;
import yugo.util.HttpClientUtils;
import yugo.util.SignUtil;

import java.util.Date;
import java.util.Map;

public class GetLabel {

    public static void main(String[] args) {

        Map<String, String> data = Maps.newHashMap();
        data.put("orderNo", "PO19122000001204");
//        data.put("labelType", "single");

        ApiRequest apiRequest = new ApiRequest();
        apiRequest.setAction("api.postorder.getLabel");
        apiRequest.setAppKey("test");
        apiRequest.setFormat("json");
        apiRequest.setLanguage("zh_CN");
        apiRequest.setPlatform("FS");

        apiRequest.setSignMethod("md5");
        apiRequest.setTimestamp(new Date());
        apiRequest.setVersion("1.0");
        apiRequest.setData(data);

        String sign = SignUtil.getSign(apiRequest, "87ae42f6b7e049baa70c8129b541d389");
        System.out.println(sign);
        apiRequest.setSign(sign);


        String jsonData = JSON.toJSONString(apiRequest);
        System.out.println(jsonData);

//        String result = HttpClientUtils.doPost("http://127.0.0.1:8080/postkeeper/api/service", jsonData);
        String result = HttpClientUtils.doPost("http://sandbox.postkeeper.zhengfx.com/postkeeper/api/service", jsonData);
        System.out.println(result);
    }

}
