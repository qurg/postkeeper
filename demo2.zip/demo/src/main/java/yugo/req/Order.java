package yugo.req;

import lombok.Data;

import java.util.List;

@Data
public class Order {

   private String customerOrderNo; //客户订单号
   private String productCode; //产品编码
   private String warehouseCode; //仓库编码
   private String outWhTime; //发货时间,格式yyyy-MM-dd HH:mm:ss

   private String buyerName; //买方姓名
   private String buyerPhone; //买方手机号码
   private String buyerEmail; //买方邮箱
   private String buyerCountry; //买方国家
   private String buyerState; //买方所在州
   private String buyerCity; //买方所在城市
   private String buyerHouseNo; //买方房屋编号
   private String buyerPostcode; //买方邮政编码
   private String buyerAddress1; //买方地址1
   private String buyerAddress2; //买方地址2
   private String reference; //客户自定义号

   private List<Parcels> parcels; //包裹集合

}
