package yugo;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import yugo.req.ApiRequest;
import yugo.req.Order;
import yugo.req.ParcelItems;
import yugo.req.Parcels;
import yugo.util.HttpClientUtils;
import yugo.util.SignUtil;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 创建订单demo
 *
 * @version 2019-11-12
 */
public class CreateOrder {

    public static void main(String[] args) {

        Order order = new Order();
        order.setCustomerOrderNo("YG00000004");
        order.setProductCode("P2019080100000004");
        order.setWarehouseCode("ZFX_US_KY");
        order.setOutWhTime("2019-08-15 10:07:46");
        order.setBuyerName("test");
        order.setBuyerPhone("0231234111");
        order.setBuyerEmail("test@test.com");
        order.setBuyerCountry("US");
        order.setBuyerState("TX");
        order.setBuyerCity("Humble");
        order.setBuyerHouseNo("");
        order.setBuyerPostcode("77346");
        order.setBuyerAddress1("add1");
        order.setBuyerAddress2("add2");

        List<Parcels> parcelList = Lists.newArrayList();
        for (int i = 1; i < 2; i++) {

            Parcels parcels = new Parcels();
            parcels.setParcelNo("YGP00000"+i);
            parcels.setParcelDesc("pacel 00" + i);
            parcels.setLength(new BigDecimal(10));
            parcels.setWidth(new BigDecimal("10"));
            parcels.setHeight(new BigDecimal("10"));
            parcels.setWeight(new BigDecimal("0.114"));
            parcels.setVolume(new BigDecimal("0.0001"));

            List<ParcelItems> parcelItemsList = Lists.newArrayList();
            for (int y = 1; y < 2; y++) {
                ParcelItems parcelItems = new ParcelItems();
                parcelItems.setItemCode("TT000"+y);
                parcelItems.setItemName("test item 000" + y);
                parcelItems.setSaleCurrency("USD");
                parcelItems.setSalePrice(new BigDecimal("12"));
                parcelItems.setDeclaredCurrency("USD");
                parcelItems.setDeclaredNameCn("测试商品");
                parcelItems.setDeclaredNameEn("test item");
                parcelItems.setDeclaredValue(new BigDecimal("10"));
                parcelItems.setLength(new BigDecimal("10"));
                parcelItems.setWidth(new BigDecimal("10"));
                parcelItems.setHeight(new BigDecimal("10"));
                parcelItems.setVolume(new BigDecimal("0.0001"));
                parcelItems.setWeight(new BigDecimal("400"));
                parcelItems.setQty(1);
                parcelItemsList.add(parcelItems);
            }
            parcels.setParcelItems(parcelItemsList);


            parcelList.add(parcels);

        }

        order.setParcels(parcelList);
        ApiRequest apiRequest = new ApiRequest();
        apiRequest.setAction("api.postorder.create");
        apiRequest.setAppKey("test");
        apiRequest.setFormat("json");
        apiRequest.setLanguage("zh_CN");
        apiRequest.setPlatform("FS");

        apiRequest.setSignMethod("md5");
        apiRequest.setTimestamp(new Date());
        apiRequest.setVersion("1.0");
        apiRequest.setData(order);

        String sign = SignUtil.getSign(apiRequest, "87ae42f6b7e049baa70c8129b541d389");
        System.out.println(sign);
        apiRequest.setSign(sign);

//        String date = DateUtils.formatDateTime(apiRequest.getTimestamp());
//        System.out.println(date);
//        String a = "87ae42f6b7e049baa70c8129b541d389actionapi.postorder.createappKeytestdata{\"buyerAddress1\":\"add1\",\"buyerAddress2\":\"add2\",\"buyerCity\":\"Humble\",\"buyerCountry\":\"US\",\"buyerEmail\":\"test@test.com\",\"buyerHouseNo\":\"\",\"buyerName\":\"test\",\"buyerPhone\":\"0231234111\",\"buyerPostcode\":\"77346\",\"buyerState\":\"TX\",\"customerOrderNo\":\"YG00000003\",\"outWhTime\":\"2019-08-15 10:07:46\",\"parcels\":[{\"height\":10,\"length\":10,\"parcelDesc\":\"pacel 001\",\"parcelItems\":[{\"declaredCurrency\":\"USD\",\"declaredNameCn\":\"测试商品\",\"declaredNameEn\":\"test item\",\"declaredValue\":10,\"height\":10,\"itemCode\":\"TT0001\",\"itemName\":\"test item 0001\",\"length\":10,\"qty\":1,\"saleCurrency\":\"USD\",\"salePrice\":12,\"volume\":0.0001,\"weight\":400,\"width\":10}],\"parcelNo\":\"YGP000001\",\"volume\":0.0001,\"weight\":0.114,\"width\":10}],\"productCode\":\"P2019080100000004\",\"warehouseCode\":\"ZFX_US_KY\"}formatjsonplatformFSsignMethodmd5timestamp"+date+"version1.087ae42f6b7e049baa70c8129b541d389";
//        String sign2 = MD5Util.getMd5(a);
//        System.out.println(a);
//        System.out.println(sign2);
//        apiRequest.setSign(sign2);

        String jsonData = JSON.toJSONString(apiRequest);
        System.out.println(jsonData);

        String result = HttpClientUtils.doPost("http://sandbox.postkeeper.zhengfx.com/postkeeper/api/service", jsonData);
        System.out.println(result);

    }

}
